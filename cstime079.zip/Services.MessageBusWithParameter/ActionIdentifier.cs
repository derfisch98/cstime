﻿namespace De.HsFlensburg.cstime079.Services.MessageBusWithParameter
{
    public class ActionIdentifier
    {
        public WeakReferenceAction Action { get; set; }
        public string IdentificationCode { get; set; }
    }
}
