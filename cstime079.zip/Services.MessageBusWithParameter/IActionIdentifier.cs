﻿namespace De.HsFlensburg.cstime079.Services.MessageBusWithParameter
{
    interface IActionParameter
    {
        void ExecuteWithParameter(object parameter);
    }
}
