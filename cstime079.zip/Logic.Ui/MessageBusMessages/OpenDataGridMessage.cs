﻿namespace De.HsFlensburg.cstime079.Logic.Ui.MessageBusMessages
{
    public class OpenDataGridMessage
    {
    }
}
