﻿namespace De.HsFlensburg.cstime079.Logic.Ui.MessageBusMessages
{
    public class OpenViewTimerWindowMessage
    {
        public string msgName;
        public int msgSecondsAbsolute;
    }
}
