﻿namespace De.HsFlensburg.cstime079.Logic.Ui.MessageBusMessages
{
    public class TimerSelectedMessage
    {
        public string Name;
        public int SecondsAbsolute;
    }
}
