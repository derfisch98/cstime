﻿using System.Windows;

namespace De.HsFlensburg.cstime079.Ui.Desktop
{
    /// <summary>
    /// Interaction logic for NewTimerWindow.xaml
    /// </summary>
    public partial class NewTimerWindow : Window
    {
        public NewTimerWindow()
        {
            InitializeComponent();
        }
    }
}
