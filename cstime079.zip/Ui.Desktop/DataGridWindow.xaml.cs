﻿using System.Windows;

namespace De.HsFlensburg.cstime079.Ui.Desktop
{
    /// <summary>
    /// Interaction logic for DataGridWindow.xaml
    /// </summary>
    public partial class DataGridWindow : Window
    {
        public DataGridWindow()
        {
            InitializeComponent();
        }
    }
}
